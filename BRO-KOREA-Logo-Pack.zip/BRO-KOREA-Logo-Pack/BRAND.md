# BRO KOREA — Brand Guide

This is the source of truth for anything branded BRO KOREA: the website, catalogs,
quotes, invoices and social media. Claude: read this before designing or writing
anything for BRO KOREA.

---

## 1. Company (public info)

| | |
|---|---|
| Name | **BRO KOREA** (always uppercase, with a space) |
| Registered Korean name | 주식회사 브로코리아 |
| Headquarters | Seoul, South Korea |
| Business Reg. No. | 201-86-30533 |
| Email | info@brokorea.com |
| Phone / WhatsApp | +82 10-3949-1286 (wa.me/821039491286) |
| Website | https://brokorea.com/ |

**Headline:** From Korea. To the World. / من كوريا إلى العالم.

**What we do:** BRO KOREA is a family-run trading company based in Seoul, South
Korea. We connect international customers with the Korean automotive market in three
areas:

- **Vehicle trading:** new and used vehicles, subject to availability and agreed specifications.
- **Automotive parts:** sourced to the customer's needs, from part numbers, product details, photos or vehicle identification.
- **Trading & export support:** sourcing, supplier communication, ordering, preparation, packaging, documents and shipping coordination.

**Customers:** worldwide. The Middle East is an important audience, but never describe
BRO KOREA as serving only one region. We operate from Korea only: no overseas offices
or branches. Worldwide service means international customer support and export
capability, subject to each destination's requirements.

**Our story:** in late 2022, a father and son began building and growing BRO KOREA
together. Do not state a founding year in marketing, and do not say anyone "took over"
the company.

**How customers order:** they tell us what they need (vehicle details, a parts list or
their requirements) and we reply with a quotation. **Prices are never shown publicly.**
Payment terms are agreed for each order.

**Don't promise:** that every part is available, perfect fitment, guaranteed condition,
or tracking for every shipment. Don't lead with specific brands (such as Mobis) in the
general company introduction.

**Languages:** English and Arabic. Arabic layouts are right-to-left.

**Tone:** direct, trustworthy and practical, like a supplier who answers fast and knows
the Korean market. No hype, no slang, and no fake reviews or invented customer names.

> Bank details are intentionally NOT in this file. This repo is public.

---

## 2. Logo

The logo is the original BRO KOREA design (BRO with the Taegukgi in the O, a red car
swoosh, and KOREA in a geometric font), redrawn as a clean vector. **Don't redesign
it, redraw it, or rebuild it from fonts. Always use the files.**

The red swoosh was redrawn in November 2026: a lighter roofline with a clear bend into the
windscreen and bonnet, and a shorter lower curve that leaves a small opening at the nose.
Every file in this pack uses that version. Replace any older copies (with the long, closed
swoosh) wherever they are still in use.

| File | Use it for |
|---|---|
| `logo.svg` / `bro-korea-logo.svg` | Default. Website header, documents, anything on white or light backgrounds |
| `logo-white.svg` / `bro-korea-logo-reverse.svg` | On navy, black or dark photos (white letters; the flag stays in color) |
| `bro-korea-logo-navy.svg` | One-color printing (stamps, engraving, single-color stickers) |
| `bro-korea-logo-black.svg` | Black-only printing, fax, photocopies |
| `bro-korea-logo-white.svg` | One-color white on colored backgrounds (e.g. red) |
| `bro-korea-icon.svg` | Round icon (the O with the flag): app icon, profile picture, watermark |
| `favicon.svg` / `favicon.ico` | Browser tab icon |
| `print/*.pdf` | Send these to print shops (vector, any size) |

**Clear space:** keep empty space around the logo at least equal to the thickness of
the O ring (about 5% of the logo's width) on every side.

**Minimum size:** 120 px wide on screens, 30 mm wide in print. Below that, use the
round icon instead.

**Don't:**
- stretch, squash or rotate the logo
- change its colors, except by using the provided variants
- change the flag (keep red on top, and keep the trigrams in their positions)
- add shadows, outlines, glows or gradients
- put the full-color logo on busy photos (use the white version on a dark overlay)
- retype "BRO KOREA" in a font as a substitute for the logo

---

## 3. Colors

| Name | HEX | RGB | CMYK (approx.) | Use |
|---|---|---|---|---|
| **BRO Navy** | `#1F2D44` | 31, 45, 68 | 54, 34, 0, 73 | Logo letters; dark backgrounds for the logo; print |
| **Korea Red** | `#CD2E3A` | 205, 46, 58 | 0, 78, 72, 20 | The swoosh and flag. On the website, also required-field marks only |
| **Korea Blue** | `#0047A0` | 0, 71, 160 | 100, 56, 0, 37 | Flag only. Use sparingly elsewhere (links at most) |
| **Black** | `#000000` | 0, 0, 0 | 0, 0, 0, 100 | Flag trigrams |
| **White** | `#FFFFFF` | 255, 255, 255 | 0, 0, 0, 0 | Backgrounds |
| Light gray | `#F4F5F7` | 244, 245, 247 | — | Section backgrounds, cards |

The red and blue are the standard Korean flag colors. CMYK values are approximate,
so ask the print shop for a proof.

**Website palette** (from the Arabic company profile; the logo colours above don't change):

| Name | HEX | Use |
|---|---|---|
| Page | `#FBFBFB` | Page background |
| Surface | `#FFFFFF` | Form fields, alternate sections |
| Soft | `#F3F4F6` | Note boxes, side panels |
| Ink | `#111317` | Headings |
| Body | `#5D646F` | Running text |
| Label | `#69717C` | Small labels and captions |
| Lines | `#E9EBEF` / `#DFE3E9` | Thin dividers |
| Deep blue | `#0F3D68` | Buttons, links, rules, step numbers |
| WhatsApp green | `#15803D` | WhatsApp buttons only |
| Night | `#090B10` | Closing section and footer |

Red is never a button or a background on the website, and green appears only on WhatsApp
actions.

---

## 4. Fonts

The same families as the Arabic company profile. All are free (SIL Open Font License).

- **Noto Sans** for English, and for Latin text inside Arabic (part numbers, email,
  VIN). Headings 700, body text 400, labels and buttons 600.
- **Noto Kufi Arabic** Bold (700) for Arabic headings.
- **Noto Sans Arabic** for Arabic text: 400 for body text, 700 for labels and buttons.

The website hosts its own copies in `assets/fonts/` (from Fontsource) instead of loading
them from Google Fonts.

---

## 5. Website setup (files in `/website`)

Put these in the site root: `favicon.ico`, `favicon.svg`, `apple-touch-icon.png`,
`icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `site.webmanifest`,
`og-image.png`. Add to every page's `<head>`:

```html
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<meta name="theme-color" content="#ffffff">
<meta property="og:image" content="https://brokorea.com/og-image.png">
```

Header logo: `logo.svg`, 60 px tall on desktop and 40–46 px on phones, with
`alt="BRO KOREA"`. On the dark footer (or any navy or black background), use
`logo-white.svg`.
