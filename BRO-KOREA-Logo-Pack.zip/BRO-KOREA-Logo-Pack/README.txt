BRO KOREA LOGO PACK
===================

WHICH FILE DO I USE?

Website ............ website/ folder (logo, favicons, share image), see BRAND.md section 5
WhatsApp/Telegram/
Instagram profile .. social/profile-picture-white.png  (or -navy / -icon)
Facebook/X/LinkedIn
cover photo ........ social/banner-1500x500.png
Invoices, quotes,
Excel catalogs ..... png/bro-korea-logo-1024.png  (transparent background)
Word / email
signature .......... png/bro-korea-logo-512.png
Print shop (cards,
signs, stickers,
boxes, stamps) ..... print/*.pdf  (vector, scales to any size)
Dark background .... png/bro-korea-logo-reverse-2048.png  or  svg/bro-korea-logo-reverse.svg
Designers .......... svg/ folder (master files)

Colors:  Navy #1F2D44   Red #CD2E3A   Blue #0047A0
Fonts:   Noto Sans (English), Noto Kufi Arabic (Arabic headings), Noto Sans Arabic (Arabic text)
Website: deep blue #0F3D68 for buttons and links; red stays in the logo
Logo:    November 2026 swoosh in every file

Full rules: BRAND.md
